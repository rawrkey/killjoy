"""KILLJOY test suite."""
