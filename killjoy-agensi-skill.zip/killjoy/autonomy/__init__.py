"""Autonomous scheduling and loop."""
