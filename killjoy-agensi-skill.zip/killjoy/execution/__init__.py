"""Order execution orchestration."""
