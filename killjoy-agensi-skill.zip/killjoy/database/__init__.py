"""Persistence models and repositories."""
