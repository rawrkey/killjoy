"""Options analysis engine."""
