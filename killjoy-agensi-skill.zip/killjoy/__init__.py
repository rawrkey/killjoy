"""KILLJOY — autonomous AI options-trading agent."""

__version__ = "0.1.0"
