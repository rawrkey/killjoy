"""Deterministic strategy interfaces."""
